#include "init.h"
int a=0;
volatile extern int16_t duty1;
volatile extern int16_t duty2;
volatile extern int16_t duty3;
volatile extern int16_t duty4;
extern u8 flag5;
extern int num5;
extern u8 Rece_num;
int main(void)
{ 
	 init();//��ʼ��
   while(1) 
	 {
		classify();//����
	 }
}




