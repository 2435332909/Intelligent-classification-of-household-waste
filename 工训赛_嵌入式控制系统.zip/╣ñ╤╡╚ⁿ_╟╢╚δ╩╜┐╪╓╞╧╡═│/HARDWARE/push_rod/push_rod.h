#ifndef __push_rod_H
#define __push_rod_H
#include "sys.h" 
void push_rod_Init(void);
#endif

