#ifndef _SHAKE_H
#define _SHAKE_H	 
#include "sys.h"  	

void EXTIX_Init(void);	//�ⲿ�жϳ�ʼ��		 					    
#endif


