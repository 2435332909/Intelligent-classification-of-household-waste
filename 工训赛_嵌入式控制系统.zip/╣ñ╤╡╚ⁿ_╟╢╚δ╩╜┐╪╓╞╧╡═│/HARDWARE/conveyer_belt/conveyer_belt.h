#ifndef __conveyer_belt_H
#define __conveyer_belt_H
#include "sys.h" 

void belt2_init(void);
void TIM2_PWM_Init(u32 arr,u32 psc);

#endif

