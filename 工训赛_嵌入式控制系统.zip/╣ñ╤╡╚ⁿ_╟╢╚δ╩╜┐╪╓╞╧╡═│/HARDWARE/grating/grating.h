#ifndef _GRATING_H
#define _GRATING_H	 
#include "sys.h"

#define griting 		GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_5) 

extern int flag;
void griting_Init(void); 		
void raster(void);
void belt(void); 
#endif

