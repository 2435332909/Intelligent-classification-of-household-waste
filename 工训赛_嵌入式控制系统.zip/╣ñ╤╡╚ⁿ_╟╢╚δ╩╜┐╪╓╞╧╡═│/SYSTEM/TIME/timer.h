#ifndef __TIMER_H
#define __TIMER_H
#include "sys.h"
extern u8 sg_start;
extern int16_t duty;
void TIM3_Int_Init(u16 arr,u16 psc);
void TIM5_cnt_Init(u32 arr,u32 psc);
void TIM4_cnt_Init(u32 arr,u32 psc);
void TIM7_cnt_Init(u32 arr,u32 psc);
#endif
