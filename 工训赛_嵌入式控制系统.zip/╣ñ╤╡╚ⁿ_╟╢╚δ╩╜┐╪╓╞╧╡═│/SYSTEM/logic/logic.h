#ifndef _LOGIC_H
#define _LOGIC_H
extern int fa;
void raster(void);
void belt(void);
void classify(void);

#endif

