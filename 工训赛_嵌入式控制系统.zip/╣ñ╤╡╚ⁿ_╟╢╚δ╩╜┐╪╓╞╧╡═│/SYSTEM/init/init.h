#ifndef _INIT_H
#define _INIT_H	 
#include "sys.h"  	
#include "logic.h"
#include "delay.h"
#include "pwm.h" 
#include "push_rod.h"
#include "lcd.h"
#include "usart.h"
#include "conveyer_belt.h"
#include "grating.h"
#include "timer.h"
#include "led.h"

void init(void);
#endif


